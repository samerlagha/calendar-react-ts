import auth from './auth'
import event from './event';

export default {
    auth,
    event
}
